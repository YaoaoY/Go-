package utils
import "fmt"

var Age int
var Name string

func init() {
	fmt.Println("util包中的inti()...")
	Age = 10
	Name = "yaoyao"
}
