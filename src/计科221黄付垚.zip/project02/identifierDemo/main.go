package main
//import "fmt"

func main(){
	//1)Golang严格区分大小写
	//2）标识符中不能包含空格


	//3)'_'是空标识符，起到占位作用(不能用来定义为变量名)
	//var _ int  = 40//err

}